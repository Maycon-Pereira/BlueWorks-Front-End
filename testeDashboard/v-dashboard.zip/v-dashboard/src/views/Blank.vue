<template>
  <h3 class="text-gray-700 text-3xl font-medium">Blank Page</h3>
</template>
